(function () {
  const messagesEl = document.getElementById("messages");
  const form = document.getElementById("chat-form");
  const input = document.getElementById("user-input");
  const sendBtn = document.getElementById("send-btn");
  const clearBtn = document.getElementById("clear-chat");
  const topicList = document.getElementById("topic-list");
  const chipsContainer = document.getElementById("suggested-chips");

  const WELCOME_HTML =
    '<p>Welcome! I can answer questions about <strong>groundwater</strong> — aquifers, recharge, quality, monitoring, climate impacts, and regional programs.</p>' +
    "<p>Choose a suggested question or type your own below.</p>";

  function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
  }

  function markdownLite(text) {
    let html = escapeHtml(text);
    html = html.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
    html = html.replace(/\*(.+?)\*/g, "<em>$1</em>");
    html = html.replace(/\n\n/g, "</p><p>");
    html = html.replace(/\n- /g, "</p><ul><li>");
    html = html.replace(/\n/g, "<br>");
    return "<p>" + html + "</p>";
  }

  function appendMessage(role, contentHtml, sources) {
    const wrap = document.createElement("div");
    wrap.className = "message " + role;

    const avatar = document.createElement("div");
    avatar.className = "avatar " + (role === "bot" ? "bot-avatar" : "user-avatar");
    avatar.setAttribute("aria-hidden", "true");
    avatar.textContent = role === "bot" ? "AG" : "You";

    const bubble = document.createElement("div");
    bubble.className = "bubble";
    bubble.innerHTML = contentHtml;

    if (sources && sources.length) {
      const src = document.createElement("div");
      src.className = "sources";
      src.innerHTML =
        "Sources: " +
        sources
          .map(function (s) {
            return (
              '<span title="Score: ' +
              s.score +
              '">' +
              escapeHtml(s.title) +
              " (" +
              escapeHtml(s.category) +
              ")</span>"
            );
          })
          .join("");
      bubble.appendChild(src);
    }

    wrap.appendChild(avatar);
    wrap.appendChild(bubble);
    messagesEl.appendChild(wrap);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function showTyping() {
    const wrap = document.createElement("div");
    wrap.className = "message bot typing";
    wrap.id = "typing-indicator";
    wrap.innerHTML =
      '<div class="avatar bot-avatar" aria-hidden="true">AG</div>' +
      '<div class="bubble"><span></span><span></span><span></span></div>';
    messagesEl.appendChild(wrap);
    messagesEl.scrollTop = messagesEl.scrollHeight;
  }

  function hideTyping() {
    const el = document.getElementById("typing-indicator");
    if (el) el.remove();
  }

  async function sendMessage(text) {
    const trimmed = (text || "").trim();
    if (!trimmed) return;

    appendMessage("user", "<p>" + escapeHtml(trimmed) + "</p>");
    input.value = "";
    input.style.height = "auto";
    sendBtn.disabled = true;
    showTyping();

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: trimmed }),
      });
      const data = await res.json();
      hideTyping();
      if (!res.ok) throw new Error(data.error || "Request failed");
      appendMessage("bot", markdownLite(data.reply || "No response."), data.sources);
    } catch (err) {
      hideTyping();
      appendMessage(
        "bot",
        "<p>Sorry, something went wrong. Please ensure the server is running and try again.</p>"
      );
      console.error(err);
    } finally {
      sendBtn.disabled = false;
      input.focus();
    }
  }

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    sendMessage(input.value);
  });

  input.addEventListener("input", function () {
    input.style.height = "auto";
    input.style.height = Math.min(input.scrollHeight, 120) + "px";
  });

  input.addEventListener("keydown", function (e) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      form.requestSubmit();
    }
  });

  clearBtn.addEventListener("click", function () {
    messagesEl.innerHTML =
      '<div class="message bot">' +
      '<div class="avatar bot-avatar" aria-hidden="true">AG</div>' +
      '<div class="bubble">' +
      WELCOME_HTML +
      "</div></div>";
  });

  chipsContainer.addEventListener("click", function (e) {
    const chip = e.target.closest(".chip");
    if (chip && chip.dataset.question) {
      sendMessage(chip.dataset.question);
    }
  });

  async function loadTopics() {
    try {
      const res = await fetch("/api/topics");
      const data = await res.json();
      topicList.innerHTML = "";
      (data.topics || []).forEach(function (t) {
        const li = document.createElement("li");
        const btn = document.createElement("button");
        btn.type = "button";
        btn.innerHTML =
          escapeHtml(t.title) + '<span class="cat">' + escapeHtml(t.category) + "</span>";
        btn.addEventListener("click", function () {
          sendMessage("Tell me about " + t.title);
        });
        li.appendChild(btn);
        topicList.appendChild(li);
      });
    } catch {
      topicList.innerHTML = '<li class="loading">Could not load topics</li>';
    }
  }

  loadTopics();
  input.focus();
})();
