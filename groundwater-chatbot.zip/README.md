# AquaGuide — Groundwater Information Chatbot

AI-assisted web application for collating and disseminating groundwater knowledge.

## Quick start (VS Code)

1. Extract this zip and open the `groundwater-chatbot` folder in VS Code.
2. Open a terminal in VS Code (`Terminal` → `New Terminal`).
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Start the server:
   ```bash
   python app.py
   ```
   Or double-click `run.bat` on Windows.

5. Open in browser: **http://127.0.0.1:5000**

## Requirements

- Python 3.10 or newer
- pip

## VS Code: Run with F5

Use the included launch configuration: press **F5** and choose **Run AquaGuide Server**.

## Project structure

```
groundwater-chatbot/
├── app.py
├── chat_engine.py
├── requirements.txt
├── run.bat
├── data/knowledge_base.json
├── templates/index.html
├── static/css/style.css
└── static/js/chat.js
```

## Production / remote server

For deployment, set `debug=False` in `app.py` and use a production WSGI server:

```bash
pip install gunicorn
gunicorn -w 2 -b 0.0.0.0:5000 app:app
```

On Windows servers, use `waitress`:

```bash
pip install waitress
waitress-serve --listen=0.0.0.0:5000 app:app
```
