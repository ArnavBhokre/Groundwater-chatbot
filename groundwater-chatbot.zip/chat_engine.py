"""Retrieval-based chat engine for groundwater knowledge dissemination."""

import json
import re
from pathlib import Path

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

DATA_PATH = Path(__file__).parent / "data" / "knowledge_base.json"

GREETING_PATTERNS = re.compile(
    r"\b(hi|hello|hey|good\s+(morning|afternoon|evening)|namaste|greetings)\b",
    re.I,
)
THANKS_PATTERNS = re.compile(r"\b(thank|thanks|thank you|dhanyavad)\b", re.I)
HELP_PATTERNS = re.compile(r"\b(help|what can you do|how do you work|capabilities)\b", re.I)


class GroundwaterChatEngine:
    def __init__(self, data_path: Path = DATA_PATH):
        self.entries = self._load(data_path)
        self._build_index()

    def _load(self, path: Path) -> list[dict]:
        with open(path, encoding="utf-8") as f:
            return json.load(f)

    def _build_index(self) -> None:
        self.corpus = [
            f"{e['title']}. {e['category']}. {e['content']}" for e in self.entries
        ]
        self.vectorizer = TfidfVectorizer(
            stop_words="english",
            ngram_range=(1, 2),
            max_features=8000,
        )
        self.matrix = self.vectorizer.fit_transform(self.corpus)

    def _retrieve(self, query: str, top_k: int = 3) -> list[tuple[dict, float]]:
        q_vec = self.vectorizer.transform([query])
        scores = cosine_similarity(q_vec, self.matrix).flatten()
        ranked = np.argsort(scores)[::-1][:top_k]
        return [(self.entries[i], float(scores[i])) for i in ranked if scores[i] > 0.05]

    def _greeting_reply(self) -> str:
        return (
            "Hello! I am **AquaGuide**, your groundwater information assistant. "
            "I can help with aquifers, recharge, monitoring, quality, management, "
            "climate impacts, and regional programs. Ask a question or try a suggested topic below."
        )

    def _help_reply(self) -> str:
        categories = sorted({e["category"] for e in self.entries})
        return (
            "I collate and disseminate groundwater knowledge from a curated knowledge base. "
            "Ask natural-language questions such as:\n\n"
            "- What is groundwater recharge?\n"
            "- How does overdraft affect aquifers?\n"
            "- Groundwater monitoring in India\n"
            "- Common contaminants in groundwater\n\n"
            f"**Topics covered:** {', '.join(categories)}\n\n"
            "I retrieve the most relevant articles and summarize answers for you."
        )

    def _format_answer(self, query: str, hits: list[tuple[dict, float]]) -> str:
        if not hits:
            return (
                "I could not find a close match in my knowledge base. "
                "Try rephrasing your question, or ask about: aquifers, recharge, "
                "water quality, monitoring wells, sustainable yield, or India CGWB programs."
            )

        primary, score = hits[0]
        lines = [
            f"**{primary['title']}** ({primary['category']})\n\n",
            primary["content"],
        ]

        if len(hits) > 1 and hits[1][1] > 0.15:
            lines.append("\n\n**Related information:**")
            for entry, s in hits[1:]:
                if s > 0.15:
                    snippet = entry["content"][:180].rstrip()
                    if len(entry["content"]) > 180:
                        snippet += "..."
                    lines.append(f"\n- **{entry['title']}:** {snippet}")

        lines.append(f"\n\n*Relevance: {score:.0%} | Source: {primary['id']}*")
        return "".join(lines)

    def respond(self, message: str) -> dict:
        text = (message or "").strip()
        if not text:
            return {"reply": "Please enter a question about groundwater.", "sources": []}

        if GREETING_PATTERNS.search(text) and len(text.split()) <= 6:
            return {"reply": self._greeting_reply(), "sources": []}

        if THANKS_PATTERNS.search(text):
            return {
                "reply": "You're welcome! Ask anytime you need groundwater information.",
                "sources": [],
            }

        if HELP_PATTERNS.search(text):
            return {"reply": self._help_reply(), "sources": []}

        hits = self._retrieve(text)
        sources = [
            {"id": e["id"], "title": e["title"], "category": e["category"], "score": round(s, 3)}
            for e, s in hits
        ]
        return {
            "reply": self._format_answer(text, hits),
            "sources": sources,
        }

    def list_topics(self) -> list[dict]:
        return [
            {"id": e["id"], "title": e["title"], "category": e["category"]}
            for e in self.entries
        ]

    def get_entry(self, entry_id: str) -> dict | None:
        for e in self.entries:
            if e["id"] == entry_id:
                return e
        return None
