@echo off
cd /d "%~dp0"
echo Installing dependencies...
python -m pip install -r requirements.txt -q
echo.
echo Starting AquaGuide server at http://127.0.0.1:5000
echo Press Ctrl+C to stop.
python app.py
pause
