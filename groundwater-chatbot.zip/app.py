"""Flask application — AI groundwater information chatbot."""

from flask import Flask, jsonify, render_template, request

from chat_engine import GroundwaterChatEngine

app = Flask(__name__)
engine = GroundwaterChatEngine()

SUGGESTED_QUESTIONS = [
    "What is groundwater and why is it important?",
    "Explain aquifer types and recharge",
    "How is groundwater monitored?",
    "What causes groundwater contamination?",
    "Sustainable yield and overdraft",
    "Groundwater resources in India",
    "Climate change impacts on aquifers",
]


@app.route("/")
def index():
    return render_template(
        "index.html",
        suggested=SUGGESTED_QUESTIONS,
        topic_count=len(engine.entries),
    )


@app.route("/api/chat", methods=["POST"])
def chat():
    data = request.get_json(silent=True) or {}
    message = data.get("message", "")
    result = engine.respond(message)
    return jsonify(result)


@app.route("/api/topics")
def topics():
    return jsonify({"topics": engine.list_topics()})


@app.route("/api/topic/<entry_id>")
def topic_detail(entry_id):
    entry = engine.get_entry(entry_id)
    if not entry:
        return jsonify({"error": "Topic not found"}), 404
    return jsonify(entry)


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
